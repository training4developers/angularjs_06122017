(function(angular) {

	"use strict";

	document.addEventListener("DOMContentLoaded", function() {

		angular.bootstrap(document.querySelector("main"), ["WidgetApp"]);

	});

})(angular);
