(function(angular) {

	"use strict";

	angular.module("WidgetApp.Constants")
		.constant("WIDGET_API_URL", "/api/widgets");

})(angular);
