(function(angular) {

	document.addEventListener("DOMContentLoaded", function() {

		angular.bootstrap(document.querySelector("main"), ["WidgetApp"]);

	});

})(angular);
